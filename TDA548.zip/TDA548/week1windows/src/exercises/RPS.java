package exercises;

import java.util.Random;
import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;

/**
 * The Rock, Paper, Scissors game
 * See https://en.wikipedia.org/wiki/Rock-paper-scissors
 */
public class RPS {

    public static void main(String[] args) {
        new RPS().program();
    }


    /*  NOTE:

         -----------  Beats -------------
         |                              |
         V                              |
        Rock (1) --> Scissors (2) --> Paper (3)


     */
    void program() {


        // -------- Input --------------


        // ----- Process -----------------


        // ---------- Output --------------


    }


}
