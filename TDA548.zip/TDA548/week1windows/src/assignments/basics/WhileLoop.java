package assignments.basics;

import static java.lang.System.*;

/*
 *   Exercising while-loop
 */
public class WhileLoop {

    public static void main(String[] args) {
        new WhileLoop().program();
    }


    void program() {
        // Write your code here
        // Comment out when finished with one and continue with next


    }



}
