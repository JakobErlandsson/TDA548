package assignments.basics;

import static java.lang.System.*;

import java.util.Scanner;

/*
 *  Program to calculate easter day for some year (1900-2099)
 */
public class EasterDay {

    public static void main(String[] args) {
        new EasterDay().program();
    }

    void program() {
        // Write your code here
        // Structure program as: Input -> Process -> Output

        int a, b, c, d, e, s, t;   // Avoid on same line (acceptable here)
        int date;
        int year;
        int month;




    }
}
