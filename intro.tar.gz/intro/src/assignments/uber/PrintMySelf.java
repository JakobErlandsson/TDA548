package assignments.uber;

/*
 * A program that prints it's own code
 *
 * This needs more advanced Java than we have presented so far.
 */
public class PrintMySelf {


    public static void main(String[] args) {
        new PrintMySelf().program();
    }

    private void program() {
        // Make the program print out itself (it's own code)!
    }
}
