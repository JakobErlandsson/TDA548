package assignments.basics;

import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;

/*
 * A program that prints my name
 */
public class HelloMe {


    public static void main(String[] args) {
        new HelloMe().program();
    }

    private void program() {
        boolean user = true;
        while (true) {

            // Make program print "Hello" + you name here!
            // Example "Hello Sven"
            String name;
            Scanner sc = new Scanner(in);

            out.print("What is your name? ");

            name = sc.next();

            out.println("Hello " + name + "!");
        }
    }
}
