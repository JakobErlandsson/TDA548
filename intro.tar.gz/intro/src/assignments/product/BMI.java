package assignments.product;

import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;

/*
 * Calculating a persons body mass index, BMI
 * See https://en.wikipedia.org/wiki/Body_mass_index
 *
 * bmi = weight / height²     (kg/m²)
 */
public class BMI {


    public static void main(String[] args) {
        new BMI().program();
    }
            void program() {
                boolean user = true;
                while (true) {
                    // Write your code here
                    double height;
                    double weight;
                    double bmi;
                    Scanner sc = new Scanner(in);

                    // Input
                    out.print("Enter height in centimeters --> ");

                    height = sc.nextDouble() / 100;

                    out.print("Enter weight in kgs --> ");

                    weight = sc.nextDouble();          // Read an int ... (when running, write input in window below + Enter)

                    // Process
                    bmi = (weight / (height * height));    // .. will be converted to double

                    // Output
                    out.println("Ditt bmi är: " + bmi);  // Output result
                }
            }

}
