/*package exercises;

import java.util.Random;
import java.util.Scanner;

import static java.lang.System.*;

/**
 * Index based version of Tic tac toe
 *
 * This i possibly a variation of the game because we continue to move the marks
 * until someone wins (NOT just place the bricks)
 */
/*public class TicTacToe {

    public static void main(String[] args) {
        new TicTacToe().program();
    }

    Scanner sc = new Scanner(in);

    void program() {
        Random rand = new Random();
        String[] players = {"olle", "pelle"};
        char[] marks = {'X', 'O'};          // Olle has X and pelle O
        char[] board = {'-', '-', '-', '-', '-', '-', '-', '-', '-'};

        // Welcome
        plotBoard();
        // current = Slumpa spelare
        int index = getPlayerSelection();

        if(isEmpty()){
            if(hasWinner){

            }
        }

    }

}*/