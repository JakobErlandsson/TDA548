package assignments.basics;

import java.util.Scanner;

import static java.lang.System.*;;

/*
 * Sum and average for integers
 */
public class SumAvg {

    public static void main(String[] args) {
        new SumAvg().program();
    }

    void program() {
        // Write your code here
        boolean stop;
        double count;   //number of inputs
        double total;   //sum of all inputs
        int test;
        stop = true;
        count = 0;
        total = 0;
        Scanner sc = new Scanner(in);
        while (stop) {
            out.print("Write an integer --> ");
            test = sc.nextInt();
            if (test >= 0) {
                total = total + test;
                count++;
            } else {
                stop = false;
            }


        }
        out.println("Count: " + count + ", " + "Total: " + total + ", " + "Average: " + (total / count));

    }

}
