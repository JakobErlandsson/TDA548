package assignments.product;

import java.util.Random;
import java.util.Scanner;

import static java.lang.System.*;

/*
 * Nim Game
 * See https://en.wikipedia.org/wiki/Nim
 *
 * Plan and process: Compare Rock, Paper Scissor from exercises !
 */
public class Nim {

    public static void main(String[] args) {
        new Nim().program();
    }

    void program() {
        Scanner sc = new Scanner(in);
        Random rand = new Random();
        int coins;
        int humanPick;
        int compPick;
        int text;
        boolean turn; //determines which player plays
        boolean next; //Allows new game
        next = true;
        while (next) {
            coins = 13;
            out.println("Welcome to NIM!");
            out.println("There are 13 coins in the pile");
            text = 4;
            turn = true;
            while (coins > 0) {
                if (coins < 4) {
                    text = coins + 1;
                }
                if (turn) { //player's turn
                    out.print("Pick a number less than " + text + ":");
                    humanPick = sc.nextInt();
                    if (humanPick > coins || humanPick > 3 || humanPick <= 0) {
                        out.println("Cheater!");

                    } else {
                        coins = coins - humanPick;
                        out.println("Player took " + humanPick);
                        out.println("There are " + coins + " left in the pile.");
                        turn = false;
                    }

                } else {    //computer's turn
                    compPick = (rand.nextInt(3) + 1);   //computer picks coins
                    if (compPick <= coins) {    //if number of coins picked by comp is allowed
                        coins = coins - compPick;
                        out.println("Computer took " + compPick);
                        out.println("There are " + coins + " left in the pile");
                        turn = true;
                    }

                }
            }
            if (turn) {
                out.println("Player won!" + "\n");
            } else {
                out.println("Computer won!" + "\n");
            }
        }


    }
}
