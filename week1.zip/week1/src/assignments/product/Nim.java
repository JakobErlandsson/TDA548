package assignments.product;

import java.util.Random;
import java.util.Scanner;

import static java.lang.System.*;

/*
 * Nim Game
 * See https://en.wikipedia.org/wiki/Nim
 *
 * Plan and process: Compare Rock, Paper Scissor from exercises !
 */
public class Nim {

    public static void main(String[] args) {
        new Nim().program();
    }

    void program() {


    }
}
