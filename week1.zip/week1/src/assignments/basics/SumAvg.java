package assignments.basics;

import java.util.Scanner;

import static java.lang.System.*;;

/*
 * Sum and average for integers
 */
public class SumAvg {

    public static void main(String[] args) {
        new SumAvg().program();
    }

    void program() {
        // Write your code here

    }

}
