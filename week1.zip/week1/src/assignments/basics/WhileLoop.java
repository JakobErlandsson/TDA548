package assignments.basics;

import static java.lang.System.*;

/*
 *   Exercising while-loop
 */
public class WhileLoop {

    public static void main(String[] args) {
        new WhileLoop().program();
    }


    void program() {
        // Write your code here
        // Comment out when finished with one and continue with next

        int number1;
        int number2;
        int number3;
        int number4;
        int number5;
        double number6;
        double pi;
        boolean sign;
        //number1 = (-20);
        //number2 = 10;
        //number3 = 5;
        //number4 = 0;
        //number5 = 2;
        //number6 = 1;
        //pi = 0;
        /*while (number1 < 4){
            out.print(number1++ +", ");
        }

*/
        /*while(number2 > (-11)){
            out.print(number2-- +", ");
        }
*/
        /*while (number3 < 101) {
            out.print(number3 + ", ");
            number3 = number3 + 5;

        }
*/      /*while(number4 < 91){
            out.print((number4/10.0) + ", ");
            number4 = number4 + 3;
        }
*/      /*while(number5 < 257){
            out.print("1/" + number5 + ", ");
            number5 = number5 * 2;
        }

*/
        /*sign = true;
        while (number6 < 200) {
            if (sign) {
                pi = pi + (1 / number6);
                number6 = number6 + 2;
                sign = false;
            } else {
                pi = pi - (1 / number6);
                number6 = number6 + 2;
                sign = true;
            }
        }
        out.print(pi * 4);

*/
    }
}
